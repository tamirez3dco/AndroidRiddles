package controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DataBaseAdapter
{
    static final String DATABASE_word = "Manager.db";
    static final int DATABASE_VERSION = 1;
    //writing the create table ddl command
    static final String CREATE_DICTIONARY_TABLE = "CREATE TABLE dictionary (" +
            "id	INTEGER PRIMARY KEY AUTOINCREMENT," +
            "word	TEXT NOT NULL UNIQUE," +
            "audioPath	   TEXT NOT NULL," +
            "isEnable	   TEXT NOT NULL," +
            "image 	BLOB DEFAULT NULL" +
            ");";

    public SQLiteDatabase db; // Variable to hold the database instance
    private final Context context; // Context of the application using the database
    private DataBaseHelper dbHelper; // Database open/upgrade helper
    public DataBaseAdapter(Context _context){
        context = _context;
        dbHelper = new DataBaseHelper(context, DATABASE_word, null, DATABASE_VERSION);
    }
    public DataBaseAdapter open() throws SQLException{
        db = dbHelper.getWritableDatabase();
        return this;
    }
    public void addWord(String word,String audioPath,byte[] image,boolean isEnable) {
        ContentValues initialValues = new ContentValues();
        initialValues.put("word",word);
        initialValues.put("audioPath",audioPath);
        initialValues.put("isEnable",isEnable);
        initialValues.put("image",image);
        db.insert("dictionary", null, initialValues);
    }
    public Cursor getAllWords(){
        return db.rawQuery("SELECT * FROM dictionary ORDER BY word ASC;",null);
    }
    public Cursor getPath(String id,String word){
        return db.rawQuery("SELECT audioPath FROM dictionary WHERE id='"+id+"'AND word='"+word+"';",null);
    }
    public Cursor getId(String word){
        return db.rawQuery("SELECT id FROM dictionary WHERE word='"+word+"';",null);
    }
    public void updateCheckBox(String id,boolean isEnable){
        db.execSQL("UPDATE dictionary SET isEnable='"+isEnable+"' WHERE id='"+id+"';");
    }
    public void updateWord(String id,String word){
        db.execSQL("UPDATE dictionary SET word='"+word+"' WHERE id='"+id+"';");
    }
    public void updateImage(String id,byte[] img){
        ContentValues data=new ContentValues();
        data.put("image",img);
        db.update("dictionary",data,"id=" + id, null);
    }
    public void close()
    {
        db.close();
    }
    public SQLiteDatabase getDatabaseInstance()
    {
        return db;
    }
}