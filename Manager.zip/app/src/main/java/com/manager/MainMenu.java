
package com.manager;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

import adapters.ListAdapter;
import controller.DataBaseAdapter;

public class MainMenu extends Activity {

    private ArrayList<String> wordId = new ArrayList<String>();
    private ArrayList<byte[]> imageList = new ArrayList<byte[]>();
    private ArrayList<String> wordsList = new ArrayList<String>();
    private ArrayList<String> audioPathList = new ArrayList<String>();
    private ArrayList<Boolean> checkBoxValueList = new ArrayList<Boolean>();
    private Button addWordBtn;
    private DataBaseAdapter dataBaseAdapter;
    private ListView listView;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);
        listView   = (ListView) findViewById(R.id.listView);
        addWordBtn = (Button)findViewById(R.id.addWordBtn);

        dataBaseAdapter = new DataBaseAdapter(this); //giving the current context
        dataBaseAdapter = dataBaseAdapter.open();    //opening writable database

        cursor = dataBaseAdapter.getAllWords();
        loadWordsInListView(); // load data in listView

        addWordBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddWord.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        cursor.close();
        dataBaseAdapter.close();
        listView.setFocusableInTouchMode(true);
        listView.setFocusable(true);
        listView.setAdapter(new ListAdapter(this, wordId, imageList, wordsList, checkBoxValueList)); //set custom ListAdapter

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), UpdateDictionary.class);
                intent.putExtra("wordId", wordId.get(position));
                intent.putExtra("text"  , wordsList.get(position));
                intent.putExtra("audioPath"  , audioPathList.get(position));
                intent.putExtra("imageList" , imageList.get(position));
                startActivity(intent);
            }
        });
    }
    public void loadWordsInListView(){
        if (cursor.moveToFirst())
        {
            while (!cursor.isAfterLast()) //if cursor reaches after last
            {
                wordId.add(cursor.getString(cursor.getColumnIndex("id")));
                wordsList.add(cursor.getString(cursor.getColumnIndex("word")));
                audioPathList.add(cursor.getString(cursor.getColumnIndex("audioPath")));
                checkBoxValueList.add(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex("isEnable"))));
                imageList.add(cursor.getBlob(cursor.getColumnIndex("image")));
                cursor.moveToNext();
            }//end while
        }//end if
    }//end loadWordsInListView

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.share_menu, menu);
        MenuItem item = menu.findItem(R.id.menu_share);


        return true;
    }

    @Override
    public void onBackPressed() {

        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        finish();
        startActivity(intent);

        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {

          }
                return super.onOptionsItemSelected(item);

    }

}
