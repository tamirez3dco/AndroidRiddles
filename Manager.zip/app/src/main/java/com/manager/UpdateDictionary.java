package com.manager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import controller.DataBaseAdapter;
import imgutils.Crop;
import imgutils.ImageHandler;

/**
 * Created by DELL on 7/19/2015.
 */
public class UpdateDictionary extends Activity {

    private Button updateWord,updateWordImage;
    private EditText wordText;
    private DataBaseAdapter dataBaseAdapter;
    private byte[] img;
    private Bitmap wordDefaultImage;
    private ImageView wordAvatar;
    private Button play,stop,record;
    private MediaRecorder myAudioRecorder;
    private String outputFile = null;
    private Activity myActivity = this; //for pickCropImage
    private ImageHandler imgHandler = new ImageHandler();
    private Context context = this;
    private String wordId,text,audioPath,textUpdated;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_layout);

        //initializing all the views
        wordAvatar      = (ImageView)findViewById(R.id.avatar);
        updateWordImage = (Button)findViewById(R.id.updateImageBtn);
        updateWord      = (Button)findViewById(R.id.updateWordBtn);
        wordText        = (EditText)findViewById(R.id.wordTextBox);

        play            =(Button)findViewById(R.id.playBtn);
        stop            =(Button)findViewById(R.id.stopBtn);
        record          =(Button)findViewById(R.id.recordBtn);

        dataBaseAdapter = new DataBaseAdapter(this); //giving the current context
        dataBaseAdapter = dataBaseAdapter.open(); //opening writable database

        stop.setEnabled(false);
        play.setEnabled(false);

        //getting the intents
        Intent intent = getIntent();
        wordId   = intent.getStringExtra("wordId");
        text     = intent.getStringExtra("text");
        audioPath= intent.getStringExtra("audioPath");
        img      = intent.getByteArrayExtra("imageList");

        outputFile = audioPath;
        textUpdated = text;
        wordText.setText(text);

        //getting and setting the default avatar
        wordDefaultImage = imgHandler.convertByteToBitmap(img);
        wordAvatar.setImageBitmap(wordDefaultImage);

        setAudioRecorder();
        
        //setting listener to update word Button
        updateWord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    updateText();
                    updateImage();
                    dataBaseAdapter.close();

                    Intent i = new Intent(context, MainMenu.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.startActivity(i);
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(context, "Unable To Update Word", Toast.LENGTH_SHORT).show();
                }
            }
        });//end update word listener

        updateWordImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // call android default gallery
                try {
                    Crop.pickImage(myActivity);
                } catch (Exception e) {
                    Toast.makeText(context, "Unable to Crop", Toast.LENGTH_SHORT).show();
                }
            }
        });//end word image listener
        
        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recordAudio();
                Toast.makeText(context, "Recording started", Toast.LENGTH_SHORT).show();
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAudio();
                setAudioRecorder();
                Toast.makeText(getApplicationContext(), "Audio Updated successfully", Toast.LENGTH_SHORT).show();
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) throws IllegalArgumentException,SecurityException,IllegalStateException {
                playAudio();
                Toast.makeText(getApplicationContext(), "Playing Audio", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void recordAudio(){
        play.setEnabled(false);
        String strFile = audioPath;
        File file = new File(strFile);
        boolean deleted = file.delete();
        File managerDir = new File(audioPath);
        // have the object build the directory structure, if needed.
        try {
            if (textUpdated != null || textUpdated != "" || textUpdated != " ") {

                myAudioRecorder.setOutputFile(audioPath);
                myAudioRecorder.prepare();
                myAudioRecorder.start();

            } else {
                Toast.makeText(context, "Unable to Record Audio", Toast.LENGTH_SHORT);
            }
        } catch (IllegalStateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        record.setEnabled(false);
        stop.setEnabled(true);

    }
    private void playAudio(){
        MediaPlayer m = new MediaPlayer();
        try {
            m.setDataSource(outputFile);}
        catch (IOException e) {
            e.printStackTrace();
        }try {
            m.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        m.start();
    }
    private void stopAudio(){
        myAudioRecorder.stop();
        myAudioRecorder.release();
        myAudioRecorder = null;

        stop.setEnabled(false);
        play.setEnabled(true);
        record.setEnabled(true);
    }
    //initialize audio recorder
    private void setAudioRecorder(){
        myAudioRecorder = new MediaRecorder();
        myAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        myAudioRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        myAudioRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
    }
    private void beginCrop(Uri source) {
        Uri destination = Uri.fromFile(new File(getCacheDir(), "cropped"));
        Crop.of(source, destination).asSquare().withMaxSize(250,250).start(this);
    }
    private void handleCrop(int resultCode, Intent result) {
        if (resultCode == RESULT_OK) {
            Uri imageUri = Crop.getOutput(result);
            try {
                wordDefaultImage = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                wordDefaultImage = imgHandler.getRoundedCornerBitmaps(wordDefaultImage, 11);
                img = imgHandler.convertBitmapToByte(wordDefaultImage);
                wordAvatar.setImageBitmap(wordDefaultImage);
            }catch(Exception e){}
        } else if (resultCode == Crop.RESULT_ERROR) {
            Toast.makeText(this, Crop.getError(result).getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    public void updateImage(){
        try {
            dataBaseAdapter.updateImage(wordId, img);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Unable To Update Image", Toast.LENGTH_SHORT).show();
        }
    }
    public void updateText(){
        textUpdated = wordText.getText().toString();
        try {
            if (!(textUpdated.equals("") || textUpdated.equals(" "))) {
                dataBaseAdapter.updateWord(wordId, textUpdated);
            }
        }catch(Exception e){e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Unable To Update Text", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent result) {
        if (requestCode == Crop.REQUEST_PICK && resultCode == RESULT_OK) {
            beginCrop(result.getData());
        } else if (requestCode == Crop.REQUEST_CROP) {
            handleCrop(resultCode, result);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(getApplicationContext(),MainMenu.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
        finish();
        super.onBackPressed();

    }
}
