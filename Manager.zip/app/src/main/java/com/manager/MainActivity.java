package com.manager;

import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;
import android.widget.ProgressBar;


public class MainActivity extends Activity {

    private ProgressBar spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = (ProgressBar)findViewById(R.id.progressBar);


        Thread logoTimer = new Thread(){
            @Override
            public void run() {
                // TODO Auto-generated method stub
                try {
                    //spinner.setVisibility(View.VISIBLE);
                    sleep(2500);
                    Intent i= new Intent(getApplicationContext(),MainMenu.class);
                    //spinner.setVisibility(View.GONE);

                    startActivity(i);
                    finish();
                } catch (InterruptedException e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }
                finally{
                    finish();
                }
            }
        };
        logoTimer.start();
    }
}
