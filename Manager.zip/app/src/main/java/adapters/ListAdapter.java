package adapters;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.manager.R;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;

import controller.DataBaseAdapter;




/**
 * Created by DELL on 2/13/2015.
 */
public class ListAdapter extends BaseAdapter
{
    //DataBaseAdapter dataBaseAdapter;
    private LayoutInflater mInflater;
    private int size;
    private ArrayList<String> wordIdList  = new ArrayList<String>();
    private ArrayList<byte[]> imageList = new ArrayList<byte[]>();
    private ArrayList<String> textList  = new ArrayList<String>();
    private ArrayList<Boolean> checkBoxValueList  = new ArrayList<Boolean>();
    private Context context;
    private DataBaseAdapter dataBaseAdapter;
    private Cursor cursor;
    private String audioPath;
    private boolean isEnable;
    private String wordId;

    public ListAdapter(Context context,ArrayList<String> wordIdList, ArrayList<byte[]> imageList,ArrayList<String> textList,ArrayList<Boolean> checkBoxValueList ) {
        mInflater = LayoutInflater.from(context);
        this.context           = context;
        this.size              = textList.size();
        this.wordIdList        = wordIdList;
        this.imageList         = imageList;
        this.textList          = textList;

        this.checkBoxValueList = checkBoxValueList;
    }

    public int getCount() {//no of list view
        return size;
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public String getAudioPath(){
        if (cursor.moveToFirst()) {
            audioPath = cursor.getString(cursor.getColumnIndex("audioPath"));
        }//end if
        return audioPath;
    }

    public View getView(final int position, View convertView, ViewGroup parent)
    {
        final ViewHolder holder;
        if (convertView == null)
        {
            convertView = mInflater.inflate(R.layout.words_list, null);
            holder = new ViewHolder();
            holder.wordImageButton    = (ImageView) convertView.findViewById(R.id.wordImageBtn);
            holder.wordText           = (TextView) convertView.findViewById(R.id.leftTextView);
            holder.playImageButton    = (ImageButton) convertView.findViewById(R.id.playBtn);

            holder.checkBox           = (CheckBox) convertView.findViewById(R.id.checkBox);
            convertView.setTag(holder);
        }
        else
        {
            holder = (ViewHolder) convertView.getTag();
        }
        if(imageList.size()!=0) {
            try{
                byte[] outImage = imageList.get(position);
                ByteArrayInputStream imageStream = new ByteArrayInputStream(outImage);
                Bitmap theImage = BitmapFactory.decodeStream(imageStream);

                holder.wordImageButton.setImageBitmap(theImage);

            }catch (Exception e){
                holder.wordImageButton.setImageResource(R.drawable.ic_launcher);
            }
        }
        else{ //if there is no image set
            holder.wordImageButton.setImageResource(R.drawable.ic_launcher);
        }

        holder.wordText.setText(textList.get(position));
        holder.checkBox.setChecked(checkBoxValueList.get(position));
        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             try {
                    dataBaseAdapter = new DataBaseAdapter(context); //giving the current context
                    dataBaseAdapter = dataBaseAdapter.open(); //opening writable database
                    if (holder.checkBox.isChecked()) {
                        holder.checkBox.setChecked(true);
                        isEnable = true;
                    } else {
                        holder.checkBox.setChecked(false);
                        isEnable = false;
                    }
                    dataBaseAdapter.updateCheckBox(wordIdList.get(position), isEnable);
                    Toast.makeText(context, "CheckBox Updated to " + isEnable, Toast.LENGTH_SHORT).show();
                    dataBaseAdapter.close();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(context, "Unable To Save CheckBox Value", Toast.LENGTH_SHORT).show();
                }
            }
        });


        holder.playImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) throws IllegalArgumentException, SecurityException, IllegalStateException {
                MediaPlayer m = new MediaPlayer();
                dataBaseAdapter = new DataBaseAdapter(context); //giving the current context
                dataBaseAdapter = dataBaseAdapter.open(); //opening writable database
                try {
                    wordId = wordIdList.get(position);
                    cursor = dataBaseAdapter.getPath(wordId, textList.get(position));

                    if (cursor.moveToFirst()) {
                        audioPath = cursor.getString(cursor.getColumnIndex("audioPath"));
                    }//end if

                    m.setDataSource(getAudioPath());
                } catch (IOException e) {
                    e.printStackTrace();
                }

                try {
                    m.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                dataBaseAdapter.close();
                m.start();
                Toast.makeText(context, "Playing audio", Toast.LENGTH_LONG).show();
            }
        });

        return convertView;
    }

    private static class ViewHolder {
        public ImageView wordImageButton;
        public TextView wordText;
        public ImageButton playImageButton;

        public CheckBox checkBox;
    }
}
